import {
  MatDivider,
  MatDividerModule
} from "./chunk-X2P4B7MF.js";
import "./chunk-442TH4LG.js";
import "./chunk-FQEM7BSC.js";
import "./chunk-SF7Q7RME.js";
import "./chunk-SDQMWN4J.js";
import "./chunk-6UHCRHZ7.js";
import "./chunk-DSK7TZNG.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
